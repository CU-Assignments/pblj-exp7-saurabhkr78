import java.sql.*;

public class Establish_Connection {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/demo_db";
        String user = "root";
        String password = "12345";

        try (Connection conn = DriverManager.getConnection(url, user, password)) {
            System.out.println("Successfully Connected....");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
